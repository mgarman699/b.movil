package com.shieldstream.tv.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shieldstream.tv.domain.EpisodeTarget
import com.shieldstream.tv.model.CatalogItem
import com.shieldstream.tv.model.Category
import com.shieldstream.tv.model.ContinueInfo
import com.shieldstream.tv.model.Episode
import com.shieldstream.tv.model.HomeFilter
import com.shieldstream.tv.strings.R as StringsR
import com.shieldstream.tv.strings.localizedStringResource
import com.shieldstream.tv.ui.component.MobileBottomBar
import com.shieldstream.tv.ui.component.MobileChip
import com.shieldstream.tv.ui.component.MobileEdge
import com.shieldstream.tv.ui.component.MobileTopBar
import com.shieldstream.tv.ui.component.TopTab
import com.shieldstream.tv.ui.component.downloadIndicatorState

/**
 * Marco del móvil: barra superior (logo, descargas, perfil, ajustes), contenido de la pestaña y barra inferior
 * (Inicio, Buscar, Episodios, Mi lista). Series/Películas son filtros dentro del Inicio.
 * Las pestañas Buscar/Episodios/Mi lista no añaden insets: los pone este marco.
 */
@Composable
internal fun MobileMainScreen(
    onOpenItem: (CatalogItem) -> Unit,
    onContinue: (CatalogItem, ContinueInfo) -> Unit,
    onOpenNewEpisode: (CatalogItem, Episode) -> Unit,
    onUpNext: (CatalogItem, Episode) -> Unit,
    onPlaySomething: (CatalogItem, EpisodeTarget?) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenDownloads: () -> Unit,
    profileInitial: String?,
    profileAvatar: Int,
    profileImage: String?,
    onSwitchProfile: () -> Unit,
) {
    var tab by rememberSaveable { mutableStateOf(TopTab.HOME) }
    var filter by rememberSaveable { mutableStateOf(HomeFilter.ALL) }
    var category by rememberSaveable { mutableStateOf<Category?>(null) }
    val episodeCenter: EpisodeCenterViewModel = hiltViewModel()
    val downloadsViewModel: DownloadsViewModel = hiltViewModel()
    val downloadList by downloadsViewModel.downloads.collectAsState()
    val episodeState by episodeCenter.uiState.collectAsState()
    LaunchedEffect(tab) { if (tab == TopTab.EPISODES) episodeCenter.activate() }

    // Atrás: cierra la categoría; en otra pestaña vuelve al Inicio; en el Inicio deja que el sistema salga de la app.
    BackHandler(enabled = category != null || tab != TopTab.HOME) {
        if (category != null) category = null else tab = TopTab.HOME
    }

    val saveable = rememberSaveableStateHolder()
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val openCategory = category
        if (openCategory != null) {
            CategoryScreen(
                category = openCategory,
                filter = filter,
                onItemClick = onOpenItem,
                onBack = { category = null },
            )
        } else {
            Column(Modifier.fillMaxSize()) {
                MobileTopBar(
                    onSettings = onOpenSettings,
                    profileInitial = profileInitial,
                    profileAvatar = profileAvatar,
                    profileImage = profileImage,
                    onProfile = onSwitchProfile,
                    downloads = downloadIndicatorState(downloadList),
                    onDownloads = onOpenDownloads,
                )
                Box(Modifier.fillMaxWidth().weight(1f)) {
                    when (tab) {
                        TopTab.SEARCH -> saveable.SaveableStateProvider("tab_SEARCH") {
                            SearchScreen(onItemClick = onOpenItem)
                        }
                        TopTab.EPISODES -> EpisodeCenterScreen(onOpenEpisode = onOpenNewEpisode, viewModel = episodeCenter)
                        TopTab.MY_LIST -> saveable.SaveableStateProvider("tab_MY_LIST") {
                            MyListScreen(onItemClick = onOpenItem)
                        }
                        else -> Column(Modifier.fillMaxSize()) {
                            FilterRow(selected = filter, onSelect = { filter = it })
                            MobileHomeScreen(
                                filter = filter,
                                onItemClick = onOpenItem,
                                onContinueClick = onContinue,
                                onNewEpisodeClick = onOpenNewEpisode,
                                onUpNextClick = onUpNext,
                                onPlaySomething = onPlaySomething,
                                onOpenCategory = { category = it },
                                onContentReady = episodeCenter::activate,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
                MobileBottomBar(
                    selected = tab,
                    onSelect = { tab = it },
                    newEpisodeCount = (episodeState as? EpisodeCenterUiState.Content)?.newEpisodeCount ?: 0,
                )
            }
        }
    }
}

@Composable
private fun FilterRow(selected: HomeFilter, onSelect: (HomeFilter) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = MobileEdge, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp),
    ) {
        val options = listOf(
            HomeFilter.ALL to localizedStringResource(StringsR.string.mobile_home_filter_all),
            HomeFilter.TV to localizedStringResource(StringsR.string.common_tv_shows),
            HomeFilter.MOVIES to localizedStringResource(StringsR.string.common_movies),
        )
        items(options.size) { index ->
            val (value, label) = options[index]
            MobileChip(text = label, selected = value == selected, onClick = { onSelect(value) })
        }
    }
}

/** Pantalla de categoría (nivel superior, con sus propios insets): cabecera con atrás + filas de pósteres. */
@Composable
internal fun MobileCategoryScreen(
    title: String,
    state: HomeUiState,
    onRetry: () -> Unit,
    onItemClick: (CatalogItem) -> Unit,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        com.shieldstream.tv.ui.component.MobileScreenHeader(title = title, onBack = onBack)
        when (state) {
            HomeUiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                androidx.compose.material3.CircularProgressIndicator(color = Color.White)
            }
            is HomeUiState.Error -> MobileMessage(
                message = state.message,
                actionLabel = localizedStringResource(StringsR.string.home_retry),
                onAction = onRetry,
            )
            is HomeUiState.Content -> MobileRowsList(
                rows = state.rows,
                onItemClick = onItemClick,
                modifier = Modifier.fillMaxSize().navigationBarsPadding(),
            )
        }
    }
}
