# Bambi en móvil y tableta

Bambi nació como app de Android TV (mando, 1080p horizontal). Esta rama añade una **interfaz táctil para móviles
y tabletas** sin quitar la de TV: la misma app y los mismos ViewModels, con dos capas de pantalla.

## Cómo se decide la interfaz

- `MainActivity` calcula `isMobile = !isTelevisionDevice(context)` (`core/ui/.../DeviceMode.kt`: modo UI de TV o
  característica `leanback`) y lo publica en `LocalIsMobile` (`core/ui/.../theme/Theme.kt`).
- En TV todo funciona **exactamente igual que antes**. Lo nuevo solo se ejecuta con `LocalIsMobile.current == true`.
- El manifiesto ya no exige `leanback` ni fija la orientación; la actividad gestiona los cambios de configuración
  (girar no la recrea). El reproductor fuerza horizontal mientras está abierto.
- "Seguir viendo" del launcher (Play Next / canal) solo se mantiene en TV (`WatchNextManager`).

## Reglas para escribir pantallas de móvil

1. **No romper la TV.** Patrón preferido: la función pública actual pasa a `private fun TvFoo(...)` (cuerpo sin
   tocar) y se crea `fun Foo(...)` con la misma firma que bifurca:
   `if (LocalIsMobile.current) MobileFoo(...) else TvFoo(...)`. La versión móvil va en `MobileFoo.kt` del mismo
   paquete. Si solo cambian medidas, basta `val mobile = LocalIsMobile.current` y elegir dp. Hay tests unitarios que
   llaman a funciones `internal` (por ejemplo `detailsBackAction`, `shouldRequestExit`): mantén sus firmas.
2. **Borde a borde.** En móvil la ventana va bajo las barras del sistema. Cada pantalla de móvil de nivel superior
   debe respetar los huecos: `statusBarsPadding()` arriba (o `MobileScreenHeader` / `MobileTopBar`, que ya lo hacen),
   `navigationBarsPadding()` abajo, `imePadding()` en formularios con teclado. Una pantalla que vive *dentro* de
   `MobileMainScreen` (Buscar, Episodios, Mi lista) NO añade esos huecos: ya los pone el marco.
3. **Táctil primero, vertical primero**, pero sin romper en horizontal ni en tabletas: `LazyVerticalGrid` con
   `GridCells.Adaptive`, `widthIn(max = …)` para contenido que no debe estirarse. Zonas táctiles ≥ 48 dp, texto de
   cuerpo ≥ 14 sp, margen lateral `MobileEdge` (16 dp).
4. **Nada de pistas de mando**: sin "Mantén OK", sin flechas ◀ ▶, sin `FocusRequester` que roben el foco al abrir
   (en móvil abren el teclado o hacen scroll solos). Las pulsaciones largas se explican con
   `mobile_hold_for_options`. Lo que solo tiene sentido con mando o con "configúralo desde el móvil" (servidor
   LAN de configuración, QR para escanear con el móvil) se oculta o se sustituye por la acción directa.
5. **Sin dependencias nuevas** y sin `material-icons` (no está en el proyecto: los iconos son `ImageVector`
   propios en `AppIcons`, `LineIcons`, `MobileIcons`). No hay SDK de Android en el entorno donde se escribió esto,
   así que **no se ha podido compilar**: usa solo APIs que ya aparecen en el repo o estables de Compose 1.8 /
   Material 3 1.3, comprueba cada import y cada símbolo con grep, y deja el código sencillo.
6. **Textos**: recursos en `core/strings` (`values/` en inglés y `values-es/` en español). Para textos nuevos de
   móvil, un fichero propio por área, `mobile_<area>.xml` en ambos, con nombres `mobile_<area>_…`
   (`mobile_back`, `mobile_close`… ya existen en `mobile.xml`). Uso: `localizedStringResource(StringsR.string.x)`.

## Piezas disponibles (`core/ui`, paquete `com.shieldstream.tv.ui.component`)

| Pieza | Para qué |
|---|---|
| `MobileScreenHeader(title, onBack, actions)` | Cabecera de pantalla secundaria (flecha atrás + título), con barra de estado |
| `MobileTopBar(...)` | Barra superior del Inicio (logo, descargas, perfil, ajustes) |
| `MobileBottomBar(selected, onSelect, newEpisodeCount)` | Navegación inferior (Inicio, Buscar, Episodios, Mi lista) |
| `MobileIconButton(icon, contentDescription, onClick)` | Botón de icono con zona táctil de 48 dp |
| `MobileChip(text, selected, onClick)` | Pastilla de filtro |
| `Modifier.mobileClickable(onLongClick, onClick)` | Clic y pulsación larga con onda |
| `MobileIcons` | Back, Replay, More, Lock, ChevronRight/Down, Subtitles |
| `mobilePosterWidth()`, `MobileEdge`, `MobileRowSpacing` | Medidas de las filas de pósteres |
| `PosterCard(width = …)`, `CatalogPosterCard`, `ContinueCard`, `NewEpisodeCard`, `LabeledPosterCard` | Tarjetas existentes; sirven en táctil (clic y `onLongClick`) |
| `ActionMenuDialog`, `BottomActionDialog` | Ya se muestran como hoja inferior con filas anchas en móvil; tocar fuera o Atrás cierra |
| `MobileActionRow(text, icon, onClick)` | Fila ancha de 56 dp para hojas/menús propios |
| `TvButton` | Funciona con el dedo; en formularios móviles puedes usar `Button` de Material 3 |

## Estado

Ver el resumen de cambios al final de este fichero (lo mantiene quien termina cada bloque).

### Cambios por bloque

- **Base**: `LocalIsMobile` (core/ui), `MainActivity` (borde a borde en móvil, `watchNext` solo en TV), manifiesto
  (`leanback`/`touchscreen` no obligatorios, sin orientación forzada, `configChanges`, `adjustResize`),
  piezas comunes `Mobile*` y hojas inferiores.
- **Inicio** (`feature:home`): `MainScreen` delega en `MobileMainScreen` (barra superior, pestañas inferiores, filtros
  Todo/Series/Películas) o en `TvMainScreen`. `MobileHomeScreen` (cartel con paginador, atajos «Reproducir algo» /
  «Sorpréndeme», categorías), `MobileRows` (filas con pulsación larga), `MobileSearchScreen`, `MobileMyListScreen`,
  `MobileCategoryScreen`. Episodios y Descargas usan la misma pantalla con ajustes por `LocalIsMobile`.
- **Detalles** (`feature:details`): cabecera con degradado, botones de acción a ancho completo
  (`MobileDetailsParts.kt`), valoración táctil, sin `requestFocus`. `PersonScreen` con medidas móviles.
- **Reproductor** (`feature:player`): se fuerza horizontal con sensor, modo inmersivo; capa de gestos
  (doble toque ±10 s, toque muestra/oculta), controles táctiles con `Slider`, bloqueo de pantalla, ajuste de
  subtítulos táctil (`MobilePlayerControls.kt`), panel de pistas con botón cerrar.
- **Ajustes y perfiles** (`feature:settings`): selector de perfiles en cuadrícula, edición de perfil con
  scroll/teclado (`FlowRow` para las pastillas), selector de iconos con la galería del sistema en vez del QR,
  PIN con teclas grandes, Trakt/AllDebrid con botón «Abrir la página» y «Copiar código» en lugar del QR, asistente
  inicial vertical (sin «continuar desde el móvil»), Ajustes (márgenes, toques en interruptores, idioma y buffer;
  ocultas «Configurar desde el móvil» y «Frecuencia de imagen»), Addons, Solicitudes y diálogo de actualización.
- **Navegación** (`AppNavHost`): sin intro de TV en móvil; `DownloadsRoute` recibe `onBack`.
- **Pendiente de probar** (no se pudo compilar sin Android SDK): compilar, revisar en un móvil real los
  teclados (`showKeyboardOnFocus` ahora es `true` en móvil), la rotación del reproductor y los insets en
  dispositivos con muesca. `phoneconfig/*` y `TrailerScreen` no se han tocado.
