package com.shieldstream.tv.ui.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.shieldstream.tv.strings.R as StringsR
import com.shieldstream.tv.strings.localizedStringResource
import com.shieldstream.tv.ui.R
import com.shieldstream.tv.ui.theme.AppColors

/*
 * Piezas comunes de la interfaz de móvil (táctil, vertical). Solo se usan cuando LocalIsMobile es true;
 * la interfaz de TV no las toca. Ver docs/MOBILE.md.
 */

/** Iconos extra que necesita el móvil y que no están en [AppIcons] / [LineIcons]. */
object MobileIcons {
    val Back = fill("mobile_back", "M20,11H7.83l5.59,-5.59L12,4l-8,8 8,8 1.41,-1.41L7.83,13H20v-2z")

    /** Flecha circular (rebobinar); para "adelantar" se vuelve a dibujar espejada. */
    val Replay = fill(
        "mobile_replay",
        "M12,5V1L7,6l5,5V7c3.31,0 6,2.69 6,6s-2.69,6 -6,6 -6,-2.69 -6,-6H4c0,4.42 3.58,8 8,8s8,-3.58 8,-8 -3.58,-8 -8,-8z",
    )
    val More = fill(
        "mobile_more",
        "M12,8c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM12,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2z" +
            "M12,16c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2z",
    )
    val Lock = AppIcons.Lock
    val ChevronRight = fill("mobile_chevron_right", "M10,6L8.59,7.41 13.17,12l-4.58,4.59L10,18l6,-6z")
    val ChevronDown = fill("mobile_chevron_down", "M7.41,8.59L12,13.17l4.59,-4.58L18,10l-6,6 -6,-6z")
    val Subtitles = fill(
        "mobile_subtitles",
        "M20,4H4c-1.1,0 -2,0.9 -2,2v12c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V6c0,-1.1 -0.9,-2 -2,-2zM4,12h4v2H4v-2zM14,18H4v-2h10v2zM20,18h-4v-2h4v2zM20,14H10v-2h10v2z",
    )

    private fun fill(name: String, path: String): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).addPath(pathData = addPathNodes(path), fill = SolidColor(Color.White)).build()
}

/** Botón de icono con zona táctil de 48 dp y onda al pulsar. */
@Composable
fun MobileIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    size: Dp = 48.dp,
    iconSize: Dp = 24.dp,
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = contentDescription, tint = tint, modifier = Modifier.size(iconSize))
    }
}

/** Pulsar / mantener para las tarjetas del móvil (con onda). */
fun Modifier.mobileClickable(onLongClick: (() -> Unit)? = null, onClick: () -> Unit): Modifier =
    if (onLongClick == null) clickable(onClick = onClick) else combinedClickable(onLongClick = onLongClick, onClick = onClick)

/**
 * Cabecera de pantalla secundaria: flecha atrás, título y acciones a la derecha. Respeta la barra de estado
 * (la app va de borde a borde), así que va arriba del todo de la pantalla.
 */
@Composable
fun MobileScreenHeader(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            MobileIconButton(
                icon = MobileIcons.Back,
                contentDescription = localizedStringResource(StringsR.string.mobile_back),
                onClick = onBack,
            )
        } else {
            Spacer(Modifier.width(MobileEdge - 4.dp))
        }
        Text(
            text = title,
            color = Color.White,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        actions()
    }
}

/**
 * Barra superior del Inicio en móvil: marca de Bambi a la izquierda; descargas en curso, perfil activo y ajustes
 * a la derecha.
 */
@Composable
fun MobileTopBar(
    onSettings: () -> Unit,
    modifier: Modifier = Modifier,
    profileInitial: String? = null,
    profileAvatar: Int = 0,
    profileImage: String? = null,
    onProfile: () -> Unit = {},
    downloads: DownloadIndicatorState? = null,
    onDownloads: () -> Unit = {},
) {
    Row(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .padding(start = MobileEdge, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(R.drawable.bambi_logo),
            contentDescription = "Bambi",
            modifier = Modifier.size(34.dp),
        )
        Spacer(Modifier.width(10.dp))
        Image(
            painter = painterResource(R.drawable.bambi_wordmark),
            contentDescription = null,
            modifier = Modifier.height(18.dp),
        )
        Spacer(Modifier.weight(1f))
        if (downloads != null) {
            DownloadIndicator(state = downloads, onClick = onDownloads)
            Spacer(Modifier.width(8.dp))
        }
        if (profileInitial != null) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClick = onProfile),
                contentAlignment = Alignment.Center,
            ) {
                ProfileAvatar(
                    initial = profileInitial,
                    avatar = profileAvatar,
                    size = 32.dp,
                    shape = RoundedCornerShape(7.dp),
                    image = profileImage,
                )
            }
        }
        MobileIconButton(
            icon = LineIcons.Settings,
            contentDescription = localizedStringResource(StringsR.string.common_settings),
            onClick = onSettings,
        )
    }
}

/** Pestañas de la barra inferior (Series y Películas son filtros dentro del Inicio, no pestañas). */
val MobileTabs: List<TopTab> = listOf(TopTab.HOME, TopTab.SEARCH, TopTab.EPISODES, TopTab.MY_LIST)

/** Barra de navegación inferior de Material 3 con las cuatro pestañas principales. */
@Composable
fun MobileBottomBar(
    selected: TopTab,
    onSelect: (TopTab) -> Unit,
    modifier: Modifier = Modifier,
    newEpisodeCount: Int = 0,
) {
    NavigationBar(
        modifier = modifier,
        containerColor = Color(0xFF0B0B0D),
        contentColor = Color.White,
        tonalElevation = 0.dp,
    ) {
        MobileTabs.forEach { tab ->
            val label = localizedStringResource(tab.mobileLabel())
            NavigationBarItem(
                selected = tab == selected,
                onClick = { onSelect(tab) },
                icon = {
                    if (tab == TopTab.EPISODES && newEpisodeCount > 0) {
                        BadgedBox(badge = { Badge(containerColor = AppColors.Alert) }) { TabIcon(tab) }
                    } else {
                        TabIcon(tab)
                    }
                },
                label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall) },
                alwaysShowLabel = true,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White,
                    selectedTextColor = Color.White,
                    indicatorColor = Color.White.copy(alpha = 0.16f),
                    unselectedIconColor = Color.White.copy(alpha = 0.6f),
                    unselectedTextColor = Color.White.copy(alpha = 0.6f),
                ),
            )
        }
    }
}

@Composable
private fun TabIcon(tab: TopTab) {
    Icon(
        imageVector = when (tab) {
            TopTab.HOME -> LineIcons.Home
            TopTab.SEARCH -> LineIcons.Search
            TopTab.EPISODES -> LineIcons.Episodes
            TopTab.MY_LIST -> LineIcons.Bookmark
            TopTab.TV -> LineIcons.Tv
            TopTab.MOVIES -> LineIcons.Movie
        },
        contentDescription = null,
        modifier = Modifier.size(24.dp),
    )
}

private fun TopTab.mobileLabel(): Int = when (this) {
    TopTab.HOME -> StringsR.string.common_home
    TopTab.SEARCH -> StringsR.string.common_search
    TopTab.EPISODES -> StringsR.string.common_episodes
    TopTab.MY_LIST -> StringsR.string.common_my_list
    TopTab.TV -> StringsR.string.common_tv_shows
    TopTab.MOVIES -> StringsR.string.common_movies
}

/** Fila horizontal de "chips" (filtros). Cada uno es una pastilla táctil; el activo va en blanco. */
@Composable
fun MobileChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier
            .height(36.dp)
            .clip(RoundedCornerShape(50))
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.14f))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = if (selected) Color.Black else Color.White,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            maxLines = 1,
        )
    }
}

/** Separación entre los elementos de una fila horizontal de pósteres. */
val MobileRowSpacing: Arrangement.Horizontal = Arrangement.spacedBy(10.dp)
