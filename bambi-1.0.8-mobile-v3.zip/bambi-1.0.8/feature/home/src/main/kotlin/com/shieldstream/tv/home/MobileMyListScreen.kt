package com.shieldstream.tv.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shieldstream.tv.model.CatalogItem
import com.shieldstream.tv.strings.R as StringsR
import com.shieldstream.tv.strings.localizedStringResource
import com.shieldstream.tv.ui.component.MobileChip
import com.shieldstream.tv.ui.component.MobileEdge
import com.shieldstream.tv.ui.component.PosterCard
import com.shieldstream.tv.ui.component.mobilePosterWidth

/** Mi lista en móvil: chips de filtro/orden arriba y rejilla de pósteres (mantener pulsado = opciones). */
@Composable
internal fun MobileMyListScreen(
    onItemClick: (CatalogItem) -> Unit,
    viewModel: MyListViewModel,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var menuItem by remember { mutableStateOf<CatalogItem?>(null) }
    val currentFilter = when (val s = state) {
        is MyListUiState.Content -> s.filter
        is MyListUiState.Empty -> s.filter
        MyListUiState.Loading -> MyListFilter.ALL
    }
    val currentSort = when (val s = state) {
        is MyListUiState.Content -> s.sort
        is MyListUiState.Empty -> s.sort
        MyListUiState.Loading -> MyListSort.RECENT
    }
    val hidingCompleted = when (val s = state) {
        is MyListUiState.Content -> s.hideCompleted
        is MyListUiState.Empty -> s.hideCompleted
        MyListUiState.Loading -> false
    }
    val width = mobilePosterWidth()

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        val filters = listOf(
            MyListFilter.ALL to localizedStringResource(StringsR.string.home_all),
            MyListFilter.TV to localizedStringResource(StringsR.string.home_tv_shows),
            MyListFilter.MOVIES to localizedStringResource(StringsR.string.home_movies),
        )
        val sorts = listOf(
            MyListSort.NEW_FIRST to localizedStringResource(StringsR.string.home_new_first),
            MyListSort.RECENT to localizedStringResource(StringsR.string.home_recent),
            MyListSort.TITLE to localizedStringResource(StringsR.string.home_a_z),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = MobileEdge, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            items(filters.size) { i ->
                val (f, label) = filters[i]
                MobileChip(text = label, selected = f == currentFilter, onClick = { viewModel.setFilter(f) })
            }
            items(sorts.size) { i ->
                val (v, label) = sorts[i]
                MobileChip(text = label, selected = v == currentSort, onClick = { viewModel.setSort(v) })
            }
            item {
                MobileChip(
                    text = localizedStringResource(StringsR.string.home_hide_completed),
                    selected = hidingCompleted,
                    onClick = viewModel::toggleHideCompleted,
                )
            }
        }
        when (val s = state) {
            MyListUiState.Loading -> Text(
                localizedStringResource(StringsR.string.home_loading),
                color = Color.White.copy(alpha = 0.6f),
                modifier = Modifier.padding(MobileEdge),
            )
            is MyListUiState.Empty -> Text(
                if (s.filter == MyListFilter.ALL) {
                    localizedStringResource(StringsR.string.home_your_list_is_empty_add_movies_and)
                } else if (s.hideCompleted) {
                    localizedStringResource(StringsR.string.home_no_unfinished_shows_match_these_filters)
                } else {
                    localizedStringResource(StringsR.string.home_nothing_of_this_kind_in_your_list)
                },
                color = Color.White.copy(alpha = 0.6f),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(MobileEdge),
            )
            is MyListUiState.Content -> LazyVerticalGrid(
                columns = GridCells.Adaptive(width),
                contentPadding = PaddingValues(start = MobileEdge, end = MobileEdge, top = 8.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(s.items, key = { it.key }) { item ->
                    PosterCard(
                        item = item,
                        onClick = { onItemClick(item) },
                        onLongClick = { menuItem = item },
                        newEpisodeCount = s.newEpisodeCounts[item.key] ?: 0,
                        width = width,
                    )
                }
            }
        }
    }
    menuItem?.let { item ->
        MyListActions(
            item = item,
            onDetails = { menuItem = null; onItemClick(item) },
            onRemove = { menuItem = null; viewModel.remove(item) },
            onCancel = { menuItem = null },
        )
    }
}
